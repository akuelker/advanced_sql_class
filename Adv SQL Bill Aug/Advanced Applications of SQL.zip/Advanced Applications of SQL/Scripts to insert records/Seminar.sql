INSERT INTO seminar VALUES ('CM101','The Three and One Half Minute Manager')
INSERT INTO seminar VALUES ('CM102','Looking for Excellence')
INSERT INTO seminar VALUES ('CM103','How to be Interviewed by Mike Wallace')
INSERT INTO seminar VALUES ('CM104','Making Money in Sausage')
