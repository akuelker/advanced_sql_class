INSERT INTO salesrep VALUES ('001','Sam')
INSERT INTO salesrep VALUES ('002','Carla')
INSERT INTO salesrep VALUES ('003','Helen')
